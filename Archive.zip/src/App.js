
import './App.css';
import Navbar from './components/Navbar';
// import CardCarousel from './components/CardCarousel';
// import BlogSlider from './components/BlogSlider';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <Navbar/>
      <BlogSlider />
      <div className="app-inner">
        <CardCarousel height={345} />
      </div>
      </header>
    </div>
  );
}

export default App;
